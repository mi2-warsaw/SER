library(data.table)
library(h2o)
library(ggplot2)

# Uruchomienie serwera H2O
# Można też z linii komend...
# Dostęp do flow z poziomu przeglądarki: http://localhost:54321/flow/index.html
h2o_local <- h2o.init(startH2O = TRUE, nthreads = -1, max_mem_size = "5g")

#Import danych
h2o_train <- h2o.importFile(path = "data/adv_train.csv",
                            destination_frame = "adv_train",
                            header = TRUE,
                            sep = ";",
                            parse = TRUE)

h2o_test <- h2o.importFile(path = "data/adv_test.csv",
                           destination_frame = "adv_test",
                           header = TRUE,
                           sep = ";",
                           parse = TRUE)

# Grid search

h2o_rf_grid <- h2o.grid(algorithm = "randomForest",
                        grid_id = "rf_grid",
                        hyper_params = list(
                          ntrees = c(50, 200)
                        ),
                        training_frame = h2o_train,
                        x = colnames(h2o_train),
                        y = "advertisement",
                        nfolds = 5,
                        seed = 1245)

# Oglądanie wyników
h2o_rf_grid

# Podsumowanie modeli (posortowane malejąco po AUC)
rf_grid_res <- h2o.getGrid(grid_id = "rf_grid",
                           sort_by = "auc",
                           decreasing = TRUE)

# Najlepszy model
rf_best_model <- h2o.getModel(model_id = rf_grid_res@model_ids[[1]])

# AUC dla najlepszego modelu
## Dla danych treningowych
h2o.auc(object = rf_best_model, train = TRUE)

## Dla walidacji krzyżowej
h2o.auc(object = rf_best_model, xval = TRUE)

# Przebudowanie modelu dla najlepszych parametrów na wszystkich danych
rf_best_params <- rf_best_model@allparameters
rf_model <- h2o.randomForest(training_frame = h2o_train,
                             model_id = "rf_model",
                             x = colnames(h2o_train),
                             y = "advertisement",
                             ntrees = rf_best_params$ntrees,
                             seed = 12345)
                             
# Zapisanie modelu
h2o.saveModel(object = rf_model,
              path = "work/",
              force = TRUE)


# Wykres krzywej lift
lift_table <- melt(as.data.table(h2o.gainsLift(object = rf_best_model, xval = TRUE)),
                   id.vars = c("group", "cumulative_data_fraction"))


ggplot(data = lift_table[variable %in% c("cumulative_lift", "cumulative_capture_rate")],
       aes(x = cumulative_data_fraction,
           y = value,
           color = variable)) +
  geom_line() +
  theme_bw()


# Wykres krzywej roc
roc_table <- h2o.performance(model = rf_best_model, xval = TRUE)@metrics$thresholds_and_metric_scores
roc_table <- as.data.table(roc_table)
roc_table[, .(fpr, tpr)]

ggplot(data = roc_table[, .(fpr, tpr)],
       aes(x = fpr,
           y = tpr,
           color = "blue")) +
  geom_line() +
  geom_line(aes(x = fpr, y = fpr, color = "red"))  +
  ggtitle(sprintf("ROC Curve, cross validation metrics, AUC = %s", h2o.auc(rf_best_model, xval = TRUE))) +
  theme_bw()
