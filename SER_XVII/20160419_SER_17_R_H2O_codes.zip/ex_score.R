library(data.table)
library(h2o)

# Uruchomienie serwera H2O
# Można też z linii komend...
# Dostęp do flow z poziomu przeglądarki: http://localhost:54321/flow/index.html
h2o_local <- h2o.init(startH2O = TRUE, nthreads = -1, max_mem_size = "5g")

#Import danych

h2o_test <- h2o.importFile(path = "data/adv_test.csv",
                           destination_frame = "adv_test",
                           header = TRUE,
                           sep = ";",
                           parse = TRUE)

# Wczytanie modelu

rf_best_model <- h2o.loadModel("work/rf_model")

# Scoring modelu
rf_score <- h2o.predict(rf_best_model,
                        newdata = h2o_test)

# Pobranie wyniku scoringu
rf_score <- h2o.cbind(rf_score,  h2o_test)

# confusion matrix w H2O
h2o.table(rf_score[, c("predict", "advertisement")])

rf_score <- as.data.table(rf_score)

rf_score[,table(predict, advertisement)]
rf_score[, ":="( predict = as.character(predict),
                 advertisement = as.character(advertisement))]

rf_score[, .(accuracy = sum(predict == advertisement)/.N,
             TP = sum(predict == "TRUE" & advertisement == "TRUE")/sum(advertisement == "TRUE"),
             TF = sum(predict == "FALSE" & advertisement == "FALSE")/sum(advertisement == "FALSE"))]
