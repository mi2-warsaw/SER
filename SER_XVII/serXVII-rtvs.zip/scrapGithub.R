# Make automated paging till response is empty
auto.page <- function(f) {
  f_call <- substitute(f)
  stopifnot(is.call(f_call))

  i <- 1
  req <- list()
  result_lst <- list()

  repeat {
    # Specify the page to download
    f_call$page <- i

    req <- eval(f_call, parent.frame())

    # Last page has empty content
    if (length(req$content)<=0) break

    result_lst[[i]] <- req$content
    i <- i+1
  }

  result_req <- req
  result_req$content <- unlist(result_lst, recursive = FALSE)

  (result_req)
}

library(dplyr)

auto.page(github::get.repository.issues('Microsoft', 'RTVS', state='all')) -> issues
issues$content %>% purrr::map(~.$title) %>% unlist -> title
issues$content %>% purrr::map(~.$state) %>% unlist %>% as.factor -> state
issues$content %>% purrr::map(~.$created_at) %>% unlist %>% as.Date -> created 
issues$content %>% purrr::map(~ifelse(is.null(.$closed_at), NA, .$closed_at)) %>% unlist %>% as.Date -> closed 
frame <- data.frame(created, closed, title, state) %>% arrange(created)
frame$issuesCount <- 1:length(created)

write.csv(frame, 'scrap.csv')

