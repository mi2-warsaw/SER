###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                  ggradar                    #
###############################################

# devtools::install_github("ricardo-bion/ggradar", dependencies=TRUE)
library(ggradar)
library(scales)

# ścieżka dostępu
setwd('..../data')

# wczytanie danych
# Źródło: https://www.fbi.gov/about-us/cjis/ucr/crime-in-the-u.s/2013/crime-in-the-u.s.-2013/tables/1tabledatadecoverviewpdf/table_1_crime_in_the_united_states_by_volume_and_rate_per_100000_inhabitants_1994-2013.xls
crime <- read.csv('crimebycity.csv', sep = ';', dec = ',', stringsAsFactors = F)

# obróbka danych i generowanie wykresu
crime %>% 
  filter(City %in% c('New York', 'Phoenix', 'Los Angeles', 'New Orleans')) %>%
  slice(c(1:2,4:5)) %>% 
  rename(Murder = Murder_and_nonnegligent_manslaughter) %>% 
  mutate(Rape = Rape/Population, 
         Robbery = Robbery/Population, 
         Property_crime = Property_crime/Population, 
         Burglary = Burglary/Population, 
         Murder = Murder/Population) %>%
  select(City, Rape, Robbery, Property_crime, Burglary, Murder) %>% 
  mutate_each(funs(rescale), - City) %>% 
  #####################
  # nowa geometria
  ggradar() +theme(legend.position = 'bottom')
  
# Wcześniej trochę bardziej zawile:
browseURL('http://stackoverflow.com/questions/9614433/creating-radar-chart-a-k-a-star-plot-spider-plot-using-ggplot2-in-r')
browseURL('http://stackoverflow.com/questions/29452431/how-to-plot-a-radar-chart-in-ggplot2-or-r')