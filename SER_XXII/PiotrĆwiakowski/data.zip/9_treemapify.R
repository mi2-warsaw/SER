###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                 treemapify                  #
###############################################

library(devtools)
# install_github("wilkox/treemapify")
library(treemapify)

data(G20)
print(G20)

# Przygotowanie obiektu:
treeMapCoordinates <- treemapify(
  G20,
  area = "Nom.GDP.mil.USD",
  fill = "HDI",
  label = "Country",
  group = "Region"
)

# wizualizacja
treeMapPlot <- ggplotify(treeMapCoordinates)
treeMapPlot

# Źródło i więcej informacji:
browseURL('https://github.com/wilkox/treemapify')


# Alternatywa:
browseURL('https://github.com/thomasp85/ggraph')
