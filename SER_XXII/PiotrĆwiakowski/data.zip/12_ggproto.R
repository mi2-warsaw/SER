###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#               ggproto cz. 1                 #
###############################################

# Na podstawie
browseURL('http://docs.ggplot2.org/current/vignettes/extending-ggplot2.html')

# Prosty ggproto:

A <- ggproto("A", # nazwa klasy obiektu 
             NULL, # klasa bazowa
  data = 0, # pole dane
  prod = function(self, n) { # definicja metody
    self$data <- self$data * n
  }
)

# Przypisanie danych do obiektu
A$data <- seq(1:10)

# Wykonanie metody
A$prod(2)

# Prezentacja wyników
A$data

##############################
# Tworzenie prostej statystyki
# Policzmy statystykę, która dla punktów zbioru buduje obwiednię (wypukłą) 

# Stworzenie nowej klasy StatChull

StatChull <- ggproto("StatChull",  # nazwa klasy
                     Stat, # dziedziczenie 
  compute_group = function(data, scales) { # metoda compute - wykonywanie obliczeń
    data[chull(data$x, data$y), , drop = FALSE] # Extract.data.frame
  },

  required_aes = c("x", "y") # wymagane estetyki, żeby wszystko działało
)

# Teraz możemy stworzyć warstwę
stat_chull <- function(mapping = NULL, data = NULL, geom = "polygon", # definiowanie podstawowych parametrów
                       position = "identity", na.rm = FALSE, show.legend = NA, 
                       inherit.aes = TRUE, ...) {
  # deklaracja warstwy
  layer(
    stat = StatChull, # nowy stat 
    data = data, # dane takie jakie użytkownik poda do funkcji
    mapping = mapping, # mapowanie jak w funckji
    geom = geom, # geometria ustalonna w funkcji
    position = position, show.legend = show.legend, inherit.aes = inherit.aes,
    params = list(na.rm = na.rm, ...) # pozostałe argumenty podane do params po przez ...
  )
}

ggplot(mpg, aes(displ, hwy)) + 
  geom_point() + 
  stat_chull(fill = NA, colour = "black")




  