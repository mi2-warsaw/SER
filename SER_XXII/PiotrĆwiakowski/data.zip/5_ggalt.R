###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                   ggalt                     #
###############################################

library(ggthemes)
library(ggalt)
library(lubridate)


# Zaznaczanie punktów
d <- data.frame(x=c(1,1,2),y=c(1,2,2)*100)

gg <- ggplot(d,aes(x,y))
gg <- gg + scale_x_continuous(expand=c(0.5,1))
gg <- gg + scale_y_continuous(expand=c(0.5,1))

# Można połączyć punkty w figurę
gg + geom_encircle(s_shape=1, expand=0) + geom_point()
# Można stworzyć większy trójkąt
gg + geom_encircle(s_shape=1, expand=0.1, colour="red") + geom_point()
# Można zaokrąglać
gg + geom_encircle(s_shape=0.5, expand=0.1, colour="purple") + geom_point()

# devtools::install_github("hrbrmstr/ggalt")

# Ścieżka dostępu
setwd('.../data')

# Dane
# Źródło danych:
# https://www.kaggle.com/account/login?ReturnUrl=%2fc%2fwalmart-recruiting-store-sales-forecasting%2fdownload%2fsampleSubmission.csv.zip
read.csv('walmart.csv', sep=';',dec = '.', stringsAsFactors = F) %>%  
  mutate(Date = as.Date(Date)) -> w

# nazwy departamentów
# wzięte z jakieś innej strony, do odszukania przez google)
depts<-c("Candy and Tobacco","Health and Beauty Aids","Stationery","Paper Goods",
         "Media and Gaming","Cameras and Supplies","Toys","Pet Supplies",
         "Sporting Goods","Automotive","Hardware","Paint and Accessories",
         "Household Chemicals","Kitchen and Dining","Small Appliances (defunct)",
         "Outdoor Living","Home Décor","Seasonal","Crafts and Fabric","Bath and Shower",
         "Books and Magazines","Bedding","Menswear","Boyswear","Shoes","Infant Apparel","Ladies’ Socks",
         "Hosiery","Sleepwear and Scrubs","Bras and Shapewear","Ladies Accessories","Jewelry",
         "Girlswear","Ladieswear","Plus Size and Maternity","Ladies’ Outerwear/Swimwear/Seasonal Apparel",
         "Service Income (TLE)","Prescription Pharmacy","Radio Grill (defunct)","Pharmacy OTC","Team Sports Apparel",
         "TLE Oil","Models","Crafts (expanded)","Sporting Goods (expanded)","Cosmetics","?1","Firearms","Optical","?2",
         "Fishing","Floral (artificial)","?3","?4","Media and Gaming (expanded)","Live Plants and Flowers (Lawn and Garden)",
         "Seasonal Pool and Spa Chemicals","Contract Wireless","Service Plans","Concept Stores and Stamps","?5","?6","?7","?8","?9","?10",
         "Celebrations","?11","Dot-Com (S2S)","?12","Furniture","Electronics","?13","Home Management and Luggage","?14","?15",
         "Large Appliances (defunct)", "?16","Infant Consumables and Hardlines","Service Deli","Commercial Bread","Impulse and Checkout",
         "Fresh/Frozen Seafood","Balloons and Fresh Flowers (defunct)","Photo Center","Financial Services",
         "Wireless","In-Store Signage","?17","Dairy","Frozen Foods","Dry Grocery","Fresh/Frozen Meat","Fresh Produce",
         "Snacks and Beverages","Liquor","Packaged Deli","Fresh Bakery","Store Supplies")

# ziarno losowania
set.seed(2004)
# Wybierzmy losowo jeden ze sklepów:
st <- sample(unique(w$Store), 1) 

# Wybierzmy 5 działów:
dep <- sample(na.omit(unique(w$Dept)), 5) 

# Wybór sklepu oraz odpowiednich działów oraz potrzebnych zmiennych
b <- w %>% filter(Store == st & Dept %in% dep) %>% 
  select(Dept,Date,Weekly_Sales) %>% mutate(Date = as.Date(Date))

# Przypisanie nazw działom
for (i in 1:5) {                         
  b$Dept[b$Dept==dep[i]]=depts[i]
}

#  Narysujmy jakiś szereg

b %>% filter(Dept %in% c('Media and Gaming'), year(Date) ==2010) %>% 
ggplot( aes(x = Date, y = Weekly_Sales, group = Dept)) + 
  theme_bw() + geom_line(colour= 'blue') +
  geom_point(colour = 'blue', size = 2) + #theme_tufte() + scale_colour_tableau() + 
  theme(plot.title = element_text(hjust = .5), legend.position = 'bottom') +
  labs(title = 'Tygodniowa sprzedaż w wybranych działach pewnego sklepu sieci Walmart')
  
# ... zaznaczymy peak

b %>% filter(Dept %in% c('Media and Gaming'), year(Date) ==2010) -> b1

ggplot(b1, aes(x = Date, y = Weekly_Sales, group = Dept)) +
 theme_bw() + geom_line(colour= 'blue') +
 geom_point(colour = 'blue', size = 2) + #theme_tufte() + scale_colour_tableau() +
 theme(plot.title = element_text(hjust = .5), legend.position = 'bottom') +
 labs(title = 'Tygodniowa sprzedaż w wybranych działach pewnego sklepu sieci Walmart') +
 geom_encircle(data = subset(b1, Weekly_Sales > 40000), aes(x = Date, y = Weekly_Sales), s_shape = .01, expand = .03, 
               colour = 'green', size = 1.4, fill = 'green', alpha = .5)

## gg_lolipop

crime <- read.csv('crimebycity.csv', sep = ';', dec = ',', stringsAsFactors = F)

crime %>% filter(State == 'NEW MEXICO') %>%
ggplot(aes(y = reorder(City, Violent_crime/Population), x = Violent_crime/Population*1000)) + 
  scale_x_continuous(expand=c(0,0), limits = c(0, 22)) +
  geom_lollipop(point.colour="steelblue", point.size=3, horizontal=TRUE) + labs(x=NULL, y=NULL, 
                title="Przestępczość w miastach - Nowy Meksyk",
                subtitle="Liczba przestępstw z użyciem siły na 1000 mieszkańców",
                caption="Przykładowa wizualizacja geometrii") + theme_bw()

crime %>% filter(State == 'NEW MEXICO') %>% 
  mutate(Violent_crime2 = Violent_crime * (1+runif(36))) %>%
ggplot(aes(y = reorder(City, Violent_crime/Population), group = City, x = Violent_crime/Population*1000, xend = Violent_crime2/Population*1000)) +
  geom_dumbbell(color="#a3c4dc", size=0.75, point.colour.l="#0e668b") +
  scale_x_continuous(expand=c(0,0), limits = c(0, 22)) +
  labs(x=NULL, y=NULL, 
                title="Wzrost przestępczość w miastach - Nowy Meksyk",
                subtitle="Liczba przestępstw z użyciem siły na 1000 mieszkańców",
                caption="Przykładowa wizualizacja geometrii") + theme_bw()

# Więcej informacji:
browseURL('https://github.com/hrbrmstr/ggalt')