###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                 ggstance                    #
###############################################

# Źródło i wyjaśnienia:
browseURL('https://github.com/lionel-/ggstance')

# Vertical
ggplot(mpg, aes(class, hwy, fill = factor(cyl))) +
  geom_boxplot()

# Horizontal with coord_flip()
ggplot(mpg, aes(class, hwy, fill = factor(cyl))) +
  geom_boxplot() +
  coord_flip()

library("ggstance")

data(mpg)

# Horizontal with ggstance
ggplot(mpg, aes(hwy, class, fill = factor(cyl))) +
  geom_boxploth()

# Facets
vertical <- ggplot(mpg, aes(factor(year), displ))+
  geom_boxplot(aes(fill = factor(cyl)))+
  facet_grid(. ~ factor(cyl), scales = "free_x")
vertical # Problem w drugim oknie

vertical + coord_flip()
vertical + facet_grid(factor(cyl) ~ ., scales = "free_x") + coord_flip()

horizontal <- ggplot(mpg, aes(displ, factor(year)))+
  geom_boxploth(aes(fill = factor(cyl))) +
  facet_grid(factor(cyl) ~ ., scales = "free_y")
horizontal
