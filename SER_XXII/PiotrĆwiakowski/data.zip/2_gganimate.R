###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                gganimate                    #
###############################################

# install.packages('gapminder')
# devtools::install_github("dgrtwo/gganimate")
setwd('..../data')

library(gapminder)
library(gganimate)

# Domyślny layout
theme_set(theme_bw())

# nawiasem mówiąc..
help(theme_set)

# Wczytanie i przekształcenie danych
read.csv('cropps.csv', sep=';', dec=',') %>% 
  gather(key = Country, value = Cropps, United.Kingdom, Poland) ->
  cropps

w <- ggplot(cropps) + 
  geom_line(aes(x = Year, y = Cropps, colour = Country, group = Country, 
                cumulative = TRUE, # czy "stare" punkty mają zostać
                frame = Year), # według jakiej zmiennej pojawiają się punkty?
            size = 2) +
  labs(title = 'Areał ziemi uprawnej - Polska v. Wielka Brytania',
       subtitle = 'lata 1500 - 2000',
       y = 'Wielkość zbiorów [ha/ca]')

# trwa to trochę długo...
gganimate(w, 'cropp.gif')

# Wczytanie danych
read.csv('pop.csv', sep=';', dec=',') %>% 
  gather(key = Country, value = Cropps, United.Kingdom, Poland) ->
  pop

# Generowanie podstawowego wykresu
w <- ggplot(pop) + 
   geom_line(aes(x = Year, y = Cropps,  group = Country), size = 2) +
  geom_line(aes(x = Year, y = Cropps, colour = Country, 
                group = Country, cumulative = TRUE, frame = Year), size = 2) +
  labs(title = 'Populacja - Polska v. Wielka Brytania',
       subtitle = 'lata 1500 - 2000',
       y = 'Populacja [w tys.]')

# trwa to trochę długo...
gganimate(w, 'pop.gif')

# Przykłady z winietki
p <- ggplot(gapminder, aes(gdpPercap, lifeExp, size = pop, color = continent, frame = year)) +
  geom_point() +
  scale_x_log10()
gganimate(p)

gganimate(p, "gapminder.gif")

# Można iterować po innej zmiennej..

p1 <- p + geom_label_repel(data = wb[R,], 
                           aes(label = country, x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP, frame = incomeID,
                               fill=incomeID), size=2) +
  theme(axis.text=element_text(size = 11, color="gray"),
        axis.title=element_text(face="italic"),
        plot.title=element_text(size=10)) +
  labs(x="GDP per capita",
       y="Health expenditure per capita [USD]",
       title="GDP per capita vs health expenditure per capita",
       subtitle = 'Europe and Asia',
       source = "World Bank",
       fill = "Income level") + theme_classic()


# Inne opcje:
# interval
browseURL('https://github.com/dgrtwo/gganimate')