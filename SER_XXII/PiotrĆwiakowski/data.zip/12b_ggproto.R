###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#               ggproto cz. 2                 #
###############################################

# Zadanie.
# 
# Stwórzmy boxplot, który oprócz mediany, zaznacza średnią. Rozwiązanie inspirowane tym
# wpisem:
# http://stackoverflow.com/questions/34876683/how-to-extend-ggplot2-boxplot-with-ggproto

# 1. Przywołajmy geom_boxplot i za pomocą F2 zajrzyjmy do środka funkcji.
# 
# Poniżej kopia:
function (mapping = NULL, data = NULL, stat = "boxplot", position = "dodge", 
  ..., outlier.colour = NULL, outlier.color = NULL, outlier.fill = NULL, 
  outlier.shape = 19, outlier.size = 1.5, outlier.stroke = 0.5, 
  outlier.alpha = NULL, notch = FALSE, notchwidth = 0.5, varwidth = FALSE, 
  na.rm = FALSE, show.legend = NA, inherit.aes = TRUE) 
{
  layer(data = data, mapping = mapping, stat = stat, geom = GeomBoxplot, 
    position = position, show.legend = show.legend, inherit.aes = inherit.aes, 
    params = list(outlier.colour = outlier.color %||% outlier.colour, 
      outlier.fill = outlier.fill, outlier.shape = outlier.shape, 
      outlier.size = outlier.size, outlier.stroke = outlier.stroke, 
      outlier.alpha = outlier.alpha, notch = notch, notchwidth = notchwidth, 
      varwidth = varwidth, na.rm = na.rm, ...))
}



# 2. Wewnątrz funkcji umieszczamy kod liczący średnią z naszych danych
function (mapping = NULL, data = NULL, stat = "boxplot", position = "dodge", 
  ..., outlier.colour = NULL, outlier.color = NULL, outlier.fill = NULL, 
  outlier.shape = 19, outlier.size = 1.5, outlier.stroke = 0.5, 
  outlier.alpha = NULL, notch = FALSE, notchwidth = 0.5, varwidth = FALSE, 
  na.rm = FALSE, show.legend = NA, inherit.aes = TRUE) 
  
  
#######
    fun_mean <- function(x) {
        return(data.frame(y = mean(x), label = round(mean(x), 3)))
    }
#######
  
{
  layer(data = data, mapping = mapping, stat = stat, geom = GeomBoxplot, 
    position = position, show.legend = show.legend, inherit.aes = inherit.aes, 
    params = list(outlier.colour = outlier.color %||% outlier.colour, 
      outlier.fill = outlier.fill, outlier.shape = outlier.shape, 
      outlier.size = outlier.size, outlier.stroke = outlier.stroke, 
      outlier.alpha = outlier.alpha, notch = notch, notchwidth = notchwidth, 
      varwidth = varwidth, na.rm = na.rm, ...))
}
    
# 3. Dorzucamy nową warstwę:
function (mapping = NULL, data = NULL, stat = "boxplot", position = "dodge", 
  ..., outlier.colour = NULL, outlier.color = NULL, outlier.fill = NULL, 
  outlier.shape = 19, outlier.size = 1.5, outlier.stroke = 0.5, 
  outlier.alpha = NULL, notch = FALSE, notchwidth = 0.5, varwidth = FALSE, 
  na.rm = FALSE, show.legend = NA, inherit.aes = TRUE) 
  
  
#######
    fun_mean <- function(x) {
        return(data.frame(y = mean(x), label = round(mean(x), 3)))
    }
#######
  
{
  layer(data = data, mapping = mapping, stat = stat, geom = GeomBoxplot, 
    position = position, show.legend = show.legend, inherit.aes = inherit.aes, 
    params = list(outlier.colour = outlier.color %||% outlier.colour, 
      outlier.fill = outlier.fill, outlier.shape = outlier.shape, 
      outlier.size = outlier.size, outlier.stroke = outlier.stroke, 
      outlier.alpha = outlier.alpha, notch = notch, notchwidth = notchwidth, 
      varwidth = varwidth, na.rm = na.rm, ...))
  
#######
# stat_summary

# Modyfikujemy: geom (na point) fun.data na fun_mean  
# Dorzucamy na koniec params kilka premtrów ustawionych "na sztywno" size, colour, shape
  layer(data = data, mapping = mapping, stat = StatSummary, 
    geom = 'point', position = position, show.legend = show.legend, 
    inherit.aes = inherit.aes, params = list(fun.data = fun_mean, 
      fun.y = fun.y, fun.ymax = fun.ymax, fun.ymin = fun.ymin, 
      fun.args = fun.args, na.rm = na.rm, size = 2, colour = 'black', shape = 18, ...))
}
    
# 4. Chcemy aby obie warstwy zostały zwrócone. Musimy zatem zapisać je do pomocniczych obiektów i zwrócić
# funkcją return(). No i przypiszmy do obiektu :)
    
geom_boxplot2 <- function (mapping = NULL, data = NULL, stat = "boxplot", position = "dodge", 
  ..., outlier.colour = NULL, outlier.color = NULL, outlier.fill = NULL, 
  outlier.shape = 19, outlier.size = 1.5, outlier.stroke = 0.5, 
  outlier.alpha = NULL, notch = FALSE, notchwidth = 0.5, varwidth = FALSE, 
  na.rm = FALSE, show.legend = NA, inherit.aes = TRUE) {
  
  
#######
    fun_mean <- function(x) {
        return(data.frame(y = mean(x), label = round(mean(x), 3)))
    }
#######
  

  l1 <- layer(data = data, mapping = mapping, stat = stat, geom = GeomBoxplot, 
    position = position, show.legend = show.legend, inherit.aes = inherit.aes, 
    params = list(outlier.colour = outlier.color %||% outlier.colour, 
      outlier.fill = outlier.fill, outlier.shape = outlier.shape, 
      outlier.size = outlier.size, outlier.stroke = outlier.stroke, 
      outlier.alpha = outlier.alpha, notch = notch, notchwidth = notchwidth, 
      varwidth = varwidth, na.rm = na.rm, ...))
  
#######
# stat_summary

# Modyfikujemy: geom (na point) fun.data na fun.mean  
# Dorzycamy na koniec params kilka premtrów ustawionych "na sztywno" size, colour, shape (na razie)
  l2 <- layer(data = data, mapping = mapping, stat = StatSummary, 
    geom = 'point', position = position, show.legend = show.legend, 
    inherit.aes = inherit.aes, params = list(fun.data = fun_mean, 
      #fun.y = fun.y, fun.ymax = fun.ymax, fun.ymin = fun.ymin, fun.args = fun.args, 
      na.rm = na.rm, size = 4, colour = 'black', shape = 18, ...))
  return(list(l1,l2))
}
    
ggplot(mtcars, aes(factor(cyl),mpg)) + geom_boxplot()

ggplot(mtcars, aes(factor(cyl),mpg)) + geom_boxplot2()


# 5. Spróbujmy dodać argumenty które modyfikują punkt z poziomu funkcji

geom_boxplot2 <- function (mapping = NULL, data = NULL, stat = "boxplot", position = "dodge", 
  ..., outlier.colour = NULL, outlier.color = NULL, outlier.fill = NULL, 
  outlier.shape = 19, outlier.size = 1.5, outlier.stroke = 0.5, 
  outlier.alpha = NULL, notch = FALSE, notchwidth = 0.5, varwidth = FALSE, 
  na.rm = FALSE, show.legend = NA, inherit.aes = TRUE, m.size = 4, m.colour = 'black', m.shape = 18) {
  
  
#######
    fun_mean <- function(x) {
        return(data.frame(y = mean(x), label = round(mean(x), 3)))
    }
#######
  

  l1 <- layer(data = data, mapping = mapping, stat = stat, geom = GeomBoxplot, 
    position = position, show.legend = show.legend, inherit.aes = inherit.aes, 
    params = list(outlier.colour = outlier.color %||% outlier.colour, 
      outlier.fill = outlier.fill, outlier.shape = outlier.shape, 
      outlier.size = outlier.size, outlier.stroke = outlier.stroke, 
      outlier.alpha = outlier.alpha, notch = notch, notchwidth = notchwidth, 
      varwidth = varwidth, na.rm = na.rm, ...))
  
#######
# stat_summary

# Modyfikujemy: geom (na point) fun.data na fun.mean  
# Dorzycamy na koniec params kilka premtrów ustawionych "na sztywno" size, colour, shape (na razie)
  l2 <- layer(data = data, mapping = mapping, stat = StatSummary, 
    geom = 'point', position = position, show.legend = show.legend, 
    inherit.aes = inherit.aes, params = list(fun.data = fun_mean, 
      #fun.y = fun.y, fun.ymax = fun.ymax, fun.ymin = fun.ymin, fun.args = fun.args, 
      na.rm = na.rm, size = m.size, colour = m.colour, shape = m.shape, ...))
  return(list(l1,l2))
}

ggplot(mtcars, aes(factor(cyl),mpg)) + geom_boxplot2(m.colour = 'orange', m.size = 6, m.shape = 12)
