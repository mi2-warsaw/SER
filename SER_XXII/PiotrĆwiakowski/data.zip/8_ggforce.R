###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                  ggforce                    #
###############################################

# ścieżka
setwd('.../data')


# install.packages('ggforce')
library(ggforce)

# Powiększenie (ze względu na pewne wartości X)
ggplot(diamonds, aes(carat, price, color = cut)) + geom_point() +
  facet_zoom(x = carat > 1.5 & carat<2)

# Powiększenie (ze względu na pewne wartości Y)
ggplot(diamonds, aes(carat, price, color = cut)) + geom_point() +
  facet_zoom(x = carat > 1.5 & carat<2, y = price > 10000 & price < 15000)

# Powiększenie (ze względu na pewne wartości Z)
ggplot(diamonds, aes(carat, price, color = cut)) + geom_point() +
  facet_zoom(x = carat > 1.5 & carat<2, y = price > 10000 & price < 15000, split = TRUE)

# Wykresy kołowe

# Dane
wb <- read.csv('wb_data.csv')

# obróbka danych
wb %>% group_by(region) %>% dplyr::count(region) -> df

# Konstruktor i podstawowe ustawienia 
p <- ggplot() + theme_no_axes() + coord_fixed()

# Pie plot:
p + geom_arc_bar(data = df,
                 aes(x0 = 0, y0 = 0, r0 = 0, r = 1, 
                     amount = n, 
                     fill = region),
                 stat = 'pie')

# Donut plot:
p + geom_arc_bar(data = df,
                 aes(x0 = 0, y0 = 0, r0 = 0.5, r = 1, 
                     amount = n, 
                     fill = region),
                 stat = 'pie')

# Wyróżnijmy jedną kategorię:
df <- df %>% mutate(akcent = c(0.4,rep(0,6)))

# I wykres
p + geom_arc_bar(data = df,
                 aes(x0 = 0, y0 = 0, r0 = 0, r = 1, 
                     amount = n, 
                     fill = region,
                     explode = akcent),
                 stat = 'pie')

# Kiedyś:
browseURL('http://www.sthda.com/english/wiki/ggplot2-pie-chart-quick-start-guide-r-software-and-data-visualization')


# Więcej informacji:
browseURL('https://cran.r-project.org/web/packages/ggforce/vignettes/Visual_Guide.html')