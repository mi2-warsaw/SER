###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                 ggrepel                     #
###############################################

rm(list = ls())

# Biblioteki
library(tidyverse)

# ścieżka
setwd('.../data')

# Dane
wb <- read.csv('wb_data.csv')

# 1. ggrepel
library(ggrepel)
p <- ggplot(data = wb, aes(x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP)) + geom_point() 

# Wykorzystując geom_text()
p + geom_text(data = wb, aes(label = country, x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP)) +
  labs(x="GDP per capita",
       y="Health expenditure per capita",
       title="GDP per capita vs health expenditure per capita")


# Ograniczmy liczbę punktów do krajów Europy i Azji
wb %>% filter(regionID=='ECS') -> wb

# Kolejna próba
p <- ggplot(data = wb, aes(x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP)) + geom_point() 
p + geom_text(data = wb, aes(label = country, x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP)) +
  labs(x="GDP per capita",
       y="Health expenditure per capita",
       title="GDP per capita vs health expenditure per capita")


# Wykorzystując geom_text_repel
p + geom_text_repel(data = wb, aes(label = country, x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP)) +
  labs(x="GDP per capita",
       y="Health expenditure per capita",
       title="GDP per capita vs health expenditure per capita")


# Wykorzystajmy teraz geom_label - zmniejszmy czcionkę - więcej pola manewru dla algorytmu
p + geom_label_repel(data = wb, aes(label = country, x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP), 
                     size=2) + # zmniejszenie czcionki
  labs(x="GDP per capita",
       y="Health expenditure per capita",
       title="GDP per capita vs health expenditure per capita")


# Zróbmy teraz formatowanie wykresu...
p1 <- p + geom_label_repel(data = wb, aes(label = country, x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP, fill=incomeID), size=2) +
  theme(axis.text=element_text(size = 11, color="gray"),
        axis.title=element_text(face="italic"),
        plot.title=element_text(size=10)) +
  labs(x="GDP per capita",
       y="Health expenditure per capita",
       title="GDP per capita vs health expenditure per capita") + theme_bw()

p1

# Więcej informacji:
browseURL('https://cran.r-project.org/web/packages/ggrepel/vignettes/ggrepel.html')

#### nowiniki -  ggplot2 2.2.1
# Nowe pola tekstowe
p1 <- p + geom_label_repel(data = wb, 
                           aes(label = country, x = NY.GDP.PCAP.CD, y = SH.XPD.PCAP, fill=incomeID), size=2) +
  theme(axis.text=element_text(size = 11, color="gray"),
        axis.title=element_text(face="italic"),
        plot.title=element_text(size=10)) +
  labs(x="GDP per capita",
       y="Health expenditure per capita [USD]",
       title="GDP per capita vs health expenditure per capita",
       subtitle = 'Europe and Asia',
       source = "World Bank",
       fill = "Income level") + theme_classic()
p1

# skale można łatwo pozycjonować

p1 + scale_x_continuous(position = "top") 

# Opcja z dodatkową skalą:
p1 + scale_y_continuous(
    "Health expenditure per capita [USD]", 
    sec.axis = sec_axis(~ . / 1000, name = "Health expenditure per capita [1000 USD]"))

# Strzałki :)
arrow <- arrow(length = unit(0.4, "cm"), type = "closed")

p1 + theme(
    axis.line = element_line(arrow = arrow))

# Kontrola legendy
p1 +  theme(legend.justification = "top", 
            legend.position = 'right',
            legend.box = "horizontal", #margin(t = 0, r = 0, b = 0, l = 0, unit = "pt")
            legend.box.margin = margin(3, 3, 3, 3, "mm"), 
            legend.margin = margin(),
            legend.box.background = element_rect(colour = "grey50"))


# Więcej informacji tutaj:
browseURL('https://blog.rstudio.org/2016/11/14/ggplot2-2-2-0/')

