###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                 ggfortify                   #
###############################################

library(ggfortify)

#ustawienie ścieżki dostępu
# setwd("X:\\pcwiakowski")
setwd('/Users/piotrcwiakowski/Dropbox/Szkolenia/4 Zaawansowana statystyka/5 Data mining')

f <- read.csv('footballers.csv', sep = ';', dec = ',')

rownames(f)<-f$name #nazwy piłkarzy zamiast numerów nazwami wierszy
f$name <- NULL #usunięcie zmiennej ze zbioru

# regresja liniowa
model1 <- lm(data = f, market_value~.)
autoplot(model1)

# Klasteryzacja
autoplot(kmeans(f, 3), data = f) + scale_colour_brewer(palette = 'Set1')

# PCA
f.pca <- prcomp(f[,5:10],
                 center = TRUE, # czy średnia ma być w zerze?
                 scale. = TRUE  #Czy zmienne mają być wycentrowane?
                )

autoplot(f.pca)

autoplot(f.pca, label = T)

f$pop_quant <- cut(f$popularity, 
                   breaks = quantile(f$popularity, probs = seq(0, 1, by=.2)), 
                   include.lowest = T)

autoplot(f.pca, data = f, colour = 'pop_quant', label = T)

f$market_quant <- cut(f$market_value, 
                   breaks = quantile(f$market_value, probs = seq(0, 1, by=.2)), 
                   include.lowest = T)

autoplot(f.pca, data = f, colour = 'market_quant', label = T)

autoplot(f.pca, data = f, colour = 'market_quant', label = T, loadings = T, loadings.label = TRUE, scale = 0)

# Więcej informacji:
browseURL('https://cran.r-project.org/web/packages/ggfortify/index.html')
