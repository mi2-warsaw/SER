###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#              ggthemes, ggtech               #
###############################################

library(ggthemes)
library(ggtech)

setwd('/Users/piotrcwiakowski/Desktop/SER/data')

# ggthemes
f <- read.csv('czas.wolny.csv', sep=';', stringsAsFactors = F)

f %>% ggplot(aes(x = wyksztalcenie, fill = rasa)) + geom_bar() -> w
w

w + theme_wsj() + scale_fill_wsj("colors6", "") + labs(title = 'Styl Wall Street Journal')

w + theme_tufte() + labs(title = 'Styl E. Tufte i kolory S. Few') + scale_fill_few()

w + theme_gdocs() + scale_fill_gdocs() + labs(title = 'Styl google docs')


# Więcej informacji tutaj:
browseURL('https://cran.r-project.org/web/packages/ggthemes/vignettes/ggthemes.html') 

# ggtech
w + theme_tech(theme="airbnb") +
  scale_fill_tech(theme="airbnb") +
  labs(title="Motyw airbnb", fill = 'Rasa:') +
  theme(legend.title = element_text(colour = 'black'))

w + theme_tech(theme="facebook") +
  scale_fill_tech(theme="facebook") + 
  labs(title="Motyw facebook", fill = 'Rasa:') +
  theme(legend.title = element_text(colour = 'black'))

# Więcej informacji tutaj:
browseURL('https://cran.r-project.org/web/packages/ggthemes/vignettes/ggthemes.html') 
