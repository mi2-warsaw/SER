###############################################
#      Spotkania entuzjastów programu R       #
#        Tidyverse - przegląd nowinek         #
#             ggplot2 extensions              #
#                 ggExtra                     # 
###############################################

library(ggthemes)
library(ggExtra)

# Ścieżka i dane
setwd('.../data')

f <- read.csv('czas.wolny.csv', sep=';', stringsAsFactors = F)

# podstawowy wykres
f %>% filter(praca>0) %>% ggplot(aes(czas_wolny, praca)) + 
  geom_point() + geom_smooth() -> wykres

ggMarginal(wykres)

ggMarginal(wykres, type = 'histogram')

ggMarginal(wykres, margins = "x", size = 2, type = "histogram",
           col = "yellow", fill = "orange")

ggMarginal(wykres, margins = "y", type = 'boxplot') 
       
ggMarginalGadget(wykres)

# Inne funkcje
    
# plotCount
df4 <- data.frame("vehicle" = c("bicycle", "car", "unicycle", "Boeing747"),
                  "NumWheels" = c(2, 4, 1, 16))
plotCount(df4) 

# Szybki barplot
df3 <- data.frame(x = paste("Letter", LETTERS, sep = "_"),
                  y = seq_along(LETTERS))
p3 <- ggplot2::ggplot(df3, ggplot2::aes(x, y)) + ggplot2::geom_point()
p3 + rotateTextX()

# Usunięcie linii siatki
p3 + rotateTextX() + removeGrid()

